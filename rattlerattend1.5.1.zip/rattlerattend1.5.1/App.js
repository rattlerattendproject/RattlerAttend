import React from 'react';
import {
  ActivityIndicator,
  AsyncStorage,
  Button,
  Image,
  KeyboardAvoidingView,
  TextInput,
  StatusBar,
  StyleSheet,
  View,
} from 'react-native';
import { DataTable } from 'react-native-paper';
import {
  createSwitchNavigator,
  createAppContainer,
} from 'react-navigation';
import { createStackNavigator, } from 'react-navigation-stack' ; 

class SignInScreen extends React.Component {
  static navigationOptions = {
    title: 'RattlerAttend',
    backgroundColor: '#ff7d00',
  };

  render() {
    return (
      <KeyboardAvoidingView style={styles.container} behavior="padding" enabled>
        <View style={styles.buttonContainer}>
          <Button 
            color="#018443" 
            title="Sign in!" 
            onPress={this._signInAsync} />
        </View>
        <View style={styles.logoimageContainer}>
          <Image
            style={{width: 200, height: 200, resizeMode: 'contain'}}
            source={require('./assets/1200px-Florida_A&M_Rattlers_logo.svg.png')}
          />
        </View>
        <TextInput style = {styles.usernameinput}
               underlineColorAndroid = "transparent"
               placeholder = "Username"
               placeholderTextColor = "#9a73ef"
               autoCapitalize = "none"
               onChangeText = {this.handleusername}/>
        <TextInput style = {styles.passwordinput}
               underlineColorAndroid = "transparent"
               placeholder = "Password"
               placeholderTextColor = "#9a73ef"
               autoCapitalize = "none"
               onChangeText = {this.handlepassword}/>
      </KeyboardAvoidingView>
    );
  }

  _signInAsync = async () => {
    await AsyncStorage.setItem('userToken', 'abc');
    this.props.navigation.navigate('App');
  };
}

class HomeScreen extends React.Component {
  static navigationOptions = {
    title: 'RattlerAttend',
  };

  render() {
    return (
      <View style={styles.container}>
       <DataTable>
        <DataTable.Header>
          <DataTable.Title>Class</DataTable.Title>
          <DataTable.Title numeric>Time</DataTable.Title>
          <DataTable.Title numeric>Absences</DataTable.Title>
        </DataTable.Header>

        <DataTable.Row>
          <DataTable.Cell>CNT</DataTable.Cell>
          <DataTable.Cell numeric>9:15-10:30 MWF</DataTable.Cell>
          <DataTable.Cell numeric>1</DataTable.Cell>
        </DataTable.Row>

        <DataTable.Row>
          <DataTable.Cell>COP</DataTable.Cell>
          <DataTable.Cell numeric>11:00-12:00 TuTh</DataTable.Cell>
          <DataTable.Cell numeric>1</DataTable.Cell>
        </DataTable.Row>

        <DataTable.Row>
          <DataTable.Cell>CIS</DataTable.Cell>
          <DataTable.Cell numeric>2:00-5:00 MW</DataTable.Cell>
          <DataTable.Cell numeric>0</DataTable.Cell>
        </DataTable.Row>

        <DataTable.Row>
          <DataTable.Cell>CNT</DataTable.Cell>
          <DataTable.Cell numeric>12:30-1:30 TuTh</DataTable.Cell>
          <DataTable.Cell numeric>2</DataTable.Cell>
        </DataTable.Row>

        <DataTable.Row>
          <DataTable.Cell>CNT</DataTable.Cell>
          <DataTable.Cell numeric>3:00-4:00 TuTh</DataTable.Cell>
          <DataTable.Cell numeric>0</DataTable.Cell>
        </DataTable.Row>
      </DataTable>
        
        <View style={styles.sidbuttonContainer}>
        <Button
          color="#018443"
          title="My Student ID"
          onPress={this._showMoreApp}
        />
        </View>
        <View style={styles.sobuttonContainer}>
        <Button
          color="#018443" 
          title="Sign out" 
          onPress={this._signOutAsync} />
        </View>
      </View>
    );
  }

  _showMoreApp = () => {
    this.props.navigation.navigate('Other');
  };

  _signOutAsync = async () => {
    await AsyncStorage.clear();
    this.props.navigation.navigate('Auth');
  };
}

class OtherScreen extends React.Component {
  static navigationOptions = {
    title: 'My Student ID',
  };

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.sidimageContainer}>
        <Image
          style={{resizeMode: 'contain',}}
          source={require('./assets/testrattlercard.jpg')}
        />
        </View>
        <StatusBar barStyle="default" />
      </View>
    );
  }

  _signOutAsync = async () => {
    await AsyncStorage.clear();
    this.props.navigation.navigate('Auth');
  };
}

class AuthLoadingScreen extends React.Component {
  constructor() {
    super();
    this._bootstrapAsync();
  }

  // Fetch the token from storage then navigate to our appropriate place
  _bootstrapAsync = async () => {
    const userToken = await AsyncStorage.getItem('userToken');

    // This will switch to the App screen or Auth screen and this loading
    // screen will be unmounted and thrown away.
    this.props.navigation.navigate(userToken ? 'App' : 'Auth');
  };

  // Render any loading content that you like here
  render() {
    return (
      <View style={styles.container}>
        <ActivityIndicator />
        <StatusBar barStyle="default" />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#018443',
  },
  buttonContainer:{
    width: '90%',
    position: 'absolute',
    bottom: 135,
    alignItems: 'center',  
    justifyContent: 'center',
    backgroundColor: '#ff7d00',
    paddingVertical: 10,    
  },
  logoimageContainer:{
    position: 'absolute',
    top: 0, 
    left: 0, 
    right: 0, 
    bottom: 400, 
    justifyContent: 'center', 
    alignItems: 'center',   
  },
  sidbuttonContainer:{
    width: '90%',
    position: 'absolute',
    bottom: 105,
    alignItems: 'center',  
    justifyContent: 'center',
    backgroundColor: '#ff7d00',
    paddingVertical: 10,    
  },
  sobuttonContainer:{
    width: '90%',
    position: 'absolute',
    bottom: 35,
    alignItems: 'center',  
    justifyContent: 'center',
    backgroundColor: '#ff7d00',
    paddingVertical: 10,    
  },
  sidimageContainer:{
    position: 'absolute',
    top: 0, 
    left: 0, 
    right: 0, 
    bottom: 0, 
    justifyContent: 'center', 
    alignItems: 'center',   
  },
  /*
  cardsobuttonContainer:{
    width: '90%',
    position: 'absolute',
    bottom: 35,
    alignItems: 'center',  
    justifyContent: 'center',
    backgroundColor: '#ff7d00',
    paddingVertical: 10,    
  }, */
  usernameinput: {
    width: '90%',
    position: 'absolute',
    bottom: 285,
    margin: 15,
    height: 40,
    borderColor: '#ff7d00',
    borderBottomWidth: 1,
   },
  passwordinput: {
    width: '90%',
    position: 'absolute',
    bottom: 220,
    margin: 15,
    height: 40,
    borderColor: '#ff7d00',
    borderBottomWidth: 1,
   },

});

const AppStack = createStackNavigator({ Home: HomeScreen, Other: OtherScreen });
const AuthStack = createStackNavigator({ SignIn: SignInScreen });

export default createAppContainer(
  createSwitchNavigator(
    {
      AuthLoading: AuthLoadingScreen,
      App: AppStack,
      Auth: AuthStack,
    },
    {
      initialRouteName: 'AuthLoading',
    }
  )
);
